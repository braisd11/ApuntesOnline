/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testdemonio;

/**
 *
 * @author user
 */
public class TestDemonio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CDemonio demoniobip=new CDemonio(); 
        ContadorAdelante c =new ContadorAdelante("c++");
    }
}
