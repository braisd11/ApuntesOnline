/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarefaavaliableud1;

import objects.MyObjectInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;
import objects.MyObjectOutputStream;

/**
 *
 * @author a22braisdr
 */
public class Menu implements Serializable{
    Scanner scan = new Scanner(System.in);
    
    private ArrayList <Empleado> listaEmpl=new ArrayList<>();
    private String ruta = "empleados.txt";
    private final File ARCHIVO = new File(ruta);

    public Menu() {
        if (!ARCHIVO.exists()){
            try {
                ARCHIVO.createNewFile();
            } catch (IOException ex) {
                System.out.println("Error al crear archivo");
            }
        }
        try {
            cargarEmpleados();
        }
        catch (IOException | ClassNotFoundException e){
            addEmptyArray();
            System.out.println("Añadido Array Vacio");
        }
        menu();
    }
    
    
    
    
    
    private void consultar(){
        String dni=pedirDni();
        Empleado consulta=null;
        try{
            consulta=buscarEmpleado(dni);
            System.out.println("NIF: " + consulta.getNIF());
            System.out.println("Nombre: " + consulta.getNome());
            System.out.println("Apellidos: " + consulta.getApellido());
            System.out.println("Salario: " + consulta.getSalario());
        } catch (NullPointerException e){
            System.out.println("Non existe un traballador con ese dni");
        }
        menu();
    }
    
    private void insertar(){
        String dni=pedirDni();
        if (comprobarEmpleado(dni)){
            System.out.println("El empleado ya existe.");
        } else {
            System.out.println("Introduce el Nombre del empleado:");
            String nombre = scan.nextLine();
            System.out.println("Introduce los apellidos del empleado:");
            String apel = scan.nextLine();
            System.out.println("Introduce el salario del empleado:");
            double sal = scan.nextDouble();
            Empleado empl = new Empleado(dni, nombre, apel, sal);
            listaEmpl.add(empl);
            guardar();
            System.out.println("Empleado creado con éxito!");
        }
        menu();
    }
    
    private boolean comprobarEmpleado(String dni) {
        boolean existe=false;
        for (Empleado e : listaEmpl){
            if (e.getNIF().equals(dni)){
                existe = true;
            }
        }
        return existe;
    }
    
    
    
    private void listar(){
        for (Empleado e : listaEmpl){
            if (!e.getNIF().equals("-1")){
                System.out.println("Nombre: " + e.getNome() + "\tNIF: " + e.getNIF());
            }
        }
        menu();
    }
    
    
    private void borrado(){
        String dni = pedirDni();
        try {
            Empleado busqueda = buscarEmpleado(dni);
            busqueda.setNIF("-1");
            guardar();
        } catch (Exception ex) {
            System.out.println("Problema al buscar el NIF del empleado.");
        }
        menu();
    }

    
    
    private void modificar (){
        String dni=pedirDni();
        System.out.println("Introduce el nuevo salario:");
        double nuevoSal = scan.nextDouble();
        scan.nextLine();
        try{
            Empleado modificacion = buscarEmpleado(dni);
            modificacion.setSalario(nuevoSal);
            guardar();
        }
        catch (NumberFormatException e){
            System.out.println("Error al introducir el salario");
        }
        menu();
    }
    
    private Empleado buscarEmpleado(String dni){
        Empleado encontrado = null;
        for (Empleado e : listaEmpl){
            if (e.getNIF().equals(dni)){
                encontrado = e;
                break;
            }
            else{
                encontrado = null;
            }
        }
        return encontrado;
    }
    
    
    private void menu(){
        System.out.println("Escolle unha opción: \n1->Consulta \n2->Inserción \n3->Modificación \n4->Borrado \n5->Listar");
        int opcion=scan.nextInt();
        scan.nextLine();
        switch (opcion) {
            case 1:
                consultar();
                break;
            case 2:
                insertar();
                break;
            case 3:
                modificar();
                break;
            case 4:
                borrado();
                break;
            case 5:
                listar();
                break;
            default:
                System.out.println("Opción incorrecta");
                menu();
                break;
        }
        
    }

    private ArrayList cargarEmpleados() throws FileNotFoundException, IOException, ClassNotFoundException {
        MyObjectInputStream lect = new MyObjectInputStream(new FileInputStream(ARCHIVO));
        ArrayList<Empleado> aux = (ArrayList<Empleado>) lect.readObject();
        listaEmpl = aux;
        System.out.println("Empleados cargados con éxito");
        lect.close();
        return listaEmpl;
    }

    private void addEmptyArray() {
        try {
            ObjectOutputStream escrit = new ObjectOutputStream(new FileOutputStream(ARCHIVO));
            escrit.writeObject(listaEmpl);
            escrit.close();
        } catch (IOException ex) {
            System.out.println("Error al crear el empleado");
        }
    }
    
    private String pedirDni() {
        boolean correcto=true;
        String dni=null;
        do {
            System.out.println("Introduce el nif:");
            dni = scan.nextLine();
            if (dni.length()!=9){
                System.out.println("El dni tiene que tener 9 caracteres");
            }
            else{
                correcto=false;
            }
        }
        while (correcto);
        return dni;
    }

    public void guardar() {
        try {
            MyObjectOutputStream escrit = new MyObjectOutputStream(new FileOutputStream(ARCHIVO));
            escrit.writeObject(listaEmpl);
            escrit.close();
        } catch (IOException ex) {
            System.out.println("Error al crear el empleado");
        }
    }
   
}
