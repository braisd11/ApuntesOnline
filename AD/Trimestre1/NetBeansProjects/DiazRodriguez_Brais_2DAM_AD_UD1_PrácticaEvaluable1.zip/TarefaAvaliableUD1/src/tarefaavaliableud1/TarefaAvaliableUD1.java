/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarefaavaliableud1;

/**
 *
 * @author a22braisdr
 */
public class TarefaAvaliableUD1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu menu=new Menu();
        
    }
    
}
